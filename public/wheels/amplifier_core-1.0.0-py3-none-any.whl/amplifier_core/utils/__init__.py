"""Utility functions for Amplifier core."""

__all__ = []
